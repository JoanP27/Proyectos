const taskForm = document.getElementById("task-form");
const imageInput = document.getElementById("image");
const imagePreview = document.getElementById("image-preview");
const taskTemplate = document.getElementById("task-template");

const pendingTasks = document.getElementById("pending-tasks");
const inProgressTasks = document.getElementById("in-progress-tasks");
const completedTasks = document.getElementById("completed-tasks");

// Fecha mínima para la fecha límite (hoy)
const deadLineInput = document.getElementById("deadLine");
const today = new Date().toISOString().split("T")[0];
deadLineInput.setAttribute("min", today);

imageInput.addEventListener("change", (e) => {
  const file = imageInput.files[0];
  imagePreview.src = "";
  imagePreview.classList.add("hidden");
  imageInput.setCustomValidity("");

  if (file) {
    if (!file.type.startsWith("image")) {
      imageInput.setCustomValidity("File must be an image");
    } else if (file.size > 200000) {
      imageInput.setCustomValidity(
        "You can't add an image larger than 200KB"
      );
    } else {
      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.addEventListener("load", () => {
        imagePreview.src = reader.result;
        imagePreview.classList.remove("hidden");
      });
    }
    imageInput.reportValidity();
  }
});

taskForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const task = {
    title: taskForm.title.value,
    description: taskForm.description.value,
    deadLine: taskForm.deadLine.value,
    image: imagePreview.classList.contains('hidden') ? null : imagePreview.src,
    status: 0, // pendiente
  };

  const taskElement = createTaskElement(task);
  addTaskToColumn(taskElement, task.status);

  taskForm.reset();
  imagePreview.src = "";
  imagePreview.classList.add("hidden");
});

function createTaskElement(task) {
  const templateClone = taskTemplate.content.cloneNode(true);
  const taskCard = templateClone.firstElementChild;

  const dateFormatter = new Intl.DateTimeFormat("es-ES", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });

  taskCard.querySelector(".title").append(task.title);
  taskCard.querySelector(".description").append(task.description);
  taskCard
    .querySelector(".deadLine")
    .append(`Fecha Límite: ${dateFormatter.format(new Date(task.deadLine))}`);

  const imageElement = taskCard.querySelector(".image");
  if (task.image) {
    imageElement.src = task.image;
    imageElement.classList.remove("hidden");
  }

  const statusSelect = taskCard.querySelector(".status-select");
  statusSelect.value = task.status;

  statusSelect.addEventListener("change", () =>
    addTaskToColumn(taskCard, +statusSelect.value)
  );
  taskCard
    .querySelector(".delete-btn")
    .addEventListener("click", () => taskCard.remove());

  return taskCard;
}

function addTaskToColumn(taskElement, status) {
  if (status === 0) {
    pendingTasks.append(taskElement);
  } else if (status === 1) {
    inProgressTasks.append(taskElement);
  } else {
    // status === 2
    completedTasks.append(taskElement);
  }
}

